import ru.ifmo.testlib.Checker;
import ru.ifmo.testlib.InStream;
import ru.ifmo.testlib.Outcome;

import java.math.BigInteger;

public class Check implements Checker {

    boolean checkProduct(long s, long t, long x, long y) {
        BigInteger sbig = BigInteger.valueOf(s);
        BigInteger tbig = BigInteger.valueOf(t);
        BigInteger xbig = BigInteger.valueOf(x);
        BigInteger ybig = BigInteger.valueOf(y);
        BigInteger res = sbig.multiply(tbig);
        return res.compareTo(xbig) >= 0 && res.compareTo(ybig) <= 0;
    }

    @Override
    public Outcome test(InStream inf, InStream ouf, InStream ans) {
        long a = inf.nextLong(), b = inf.nextLong();
        long c = inf.nextLong(), d = inf.nextLong();
        long x = inf.nextLong(), y = inf.nextLong();

        String jr = ans.nextToken().toLowerCase();
        String prt = ouf.nextToken().toLowerCase();

        if (!jr.equals("yes") && !jr.equals("no"))
            return new Outcome(Outcome.Type.FAIL, "Expected YES or NO from Jury, but received " + prt);

        if (!prt.equals("yes") && !prt.equals("no"))
            return new Outcome(Outcome.Type.PE, "Expected YES or NO from part, but received " + prt);

        if (jr.equals("yes")) {
            long s = ans.nextLong();
            long t = ans.nextLong();
            if (s < a || s > b || t < c || t > d)
                return new Outcome(Outcome.Type.FAIL, "Jury a = " + a + " or b = " + b +" doesn't satisfy constrains");
            if (!checkProduct(s, t, x, y))
                return new Outcome(Outcome.Type.FAIL, "Jury axb doesn't satisfy constrains");
        }

        if (prt.equals("yes")) {
            long s = ouf.nextLong();
            long t = ouf.nextLong();
            if (s < a || s > b || t < c || t > d || !checkProduct(s, t, x, y))
                return new Outcome(Outcome.Type.WA, "Part has invalid answer!");
        }

        if (jr.equals("yes") && prt.equals("no"))
            return new Outcome(Outcome.Type.WA, "Jury has answer, but part hasn't!");
        else if (jr.equals("no") && prt.equals("yes"))
            return new Outcome(Outcome.Type.FAIL, "Jury hasn't answer, but part has correct answer!");
        else if (jr.equals("no"))
            return new Outcome(Outcome.Type.OK, "No solution!");
        ans.nextLine();
        ans.close();
        ouf.seekEoF();
        ouf.close();
        return new Outcome(Outcome.Type.OK, "Good job!");
    }
}
