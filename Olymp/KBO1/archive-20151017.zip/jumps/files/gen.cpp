#include "testlib.h"
#include <iostream>
#include <functional>
#include <stdexcept>
using namespace std;

#define TEST(x) { if (number == currentNumber) x; currentNumber++; }

typedef long long ll;
struct Test {
    ll a, b, c, d, x, y;
    Test() {}

};

void print(Test t) {
    cout << t.a << " " << t.b << " " << t.c << " " << t.d << " " << t.x << " " << t.y << endl;
}

void print(ll a, ll b, ll c, ll d, ll x, ll y) {
    cout << a << " " << b << " " << c << " " << d << " " << x << " " << y << endl;
}

const ll MAX_VAL = 1000000000000LL;
const ll SQ = 1000000;

ll PRIMES[] = {
               999999999989LL,
               999999999961LL,
               999999999959LL,
               999999999937LL,
               999999999899LL,
               999999999877LL,
               999999999863LL,
               999999999857LL,
               999999999847LL,
               999999999767LL,

                999983,
                999979,
                999961,
                999959,
                999953,
                999931,
                999917,
                999907,
                999883,
                999863,

                499979,
                499973,
                499969,
                499957,
                499943,
                499927,
                499903,
                499897,
                499883,
                499879,
             };

void genSample(int num) {
    if (num == 1)
        print(1, 10, 5, 15, 20, 30);
    else if (num == 2)
        print(3, 9, 5, 15, 23, 50);
    else if (num == 3)
        print(6, 7, 8, 9, 100, 200);
    else
        throw runtime_error("Too large number of sample");
}

void printRandomPrimeNO(int tp) {
    int t = tp / 2;
    ll p = PRIMES[t * 10 + rnd.next(0, 9)];
    ll a = rnd.next(1LL, (p - SQ <= 0 ? 100 : p - SQ));
    ll b = p;
    ll x = p, y = p, c, d;

    if (tp % 2 == 0) {
        c = rnd.next(1LL, (p - SQ <= 0 ? 100 : p - SQ));
        d = p - 1;
    } else {
        c = p + 1;
        d = rnd.next(p + 1, MAX_VAL);
    }
    if (rnd.next(2) == 0) {
        swap(a, c);
        swap(b, d);
    }
    print(a, b, c, d, x, y);
}


typedef unsigned long long ull;
const ull INF = 1e18;
ull mul(ull a, ull b) {
    ull c = a * b;
    if (a == 0) return 0;
    if (c / a != b) return INF;
    return c;
}

void randomYESTest() {
    while (true) {
        ll a = rnd.next(1LL, SQ);
        ll b = rnd.next(1LL, MAX_VAL);
        ll c = rnd.next(1LL, SQ);
        ll d = rnd.next(1LL, MAX_VAL);
        ll x = rnd.next(1LL, MAX_VAL);
        ll y = rnd.next(1LL, MAX_VAL);
        if (a > b) swap(a, b);
        if (c > d) swap(c, d);
        if (x > y) swap(x, y);
        if (mul(a, b) <= x && y <= mul(c, d)) {
            print(a, b, c, d, x, y);
            break;
        }
    }
}

void randomNOTest() {
    ll a = rnd.next(1LL, MAX_VAL);
    ll b = rnd.next(1LL, MAX_VAL);
    ll c = rnd.next(1LL, MAX_VAL);
    ll d = rnd.next(1LL, MAX_VAL);

    ll x = rnd.next(1LL, MAX_VAL);
    ll y = rnd.next(1LL, MAX_VAL);
    if (a > b) swap(a, b);
    if (c > d) swap(c, d);
    if (x > y) swap(x, y);
    print(a, b, c, d, x, y);
}

void generateTests(int number) {
    int currentNumber = 1;
    TEST(genSample(1));
    TEST(genSample(2));
    TEST(genSample(3));
    TEST(print(1, 1, 1, 1, 1, 1));
    TEST(print(MAX_VAL, MAX_VAL, MAX_VAL, MAX_VAL, MAX_VAL, MAX_VAL));
    TEST(printRandomPrimeNO(0));
    TEST(printRandomPrimeNO(2));
    TEST(printRandomPrimeNO(4));
    TEST(printRandomPrimeNO(1));
    TEST(printRandomPrimeNO(3));
    TEST(printRandomPrimeNO(5));
    TEST(print(1000, 10000, 100, 10000, SQ * 10, SQ * 10 + SQ));
    TEST(print(1000, 10000, 100, 10000, SQ * 100 - SQ, SQ * 100));
    TEST(print(1000, 10000, 100, 10000, SQ * 100, SQ * 1000));
    TEST(print(1000, 10000, 100, 10000, SQ * 100 + 1, SQ * 1000));
    TEST(print(MAX_VAL / 10, MAX_VAL, MAX_VAL / 100, MAX_VAL / 10, 1, 1000 * SQ));
    TEST(print(MAX_VAL / 100, MAX_VAL / 10, MAX_VAL / 1000, MAX_VAL / 11, 1, 10000 * SQ));
    TEST(print(100000LL, 4000000LL, 10000LL, 100000LL, 300000000117LL, 300000000220LL));
    TEST(print(100000LL, 4000000LL, 10000LL, 100000LL, 300000000117LL, 300000000120LL));
    TEST(print(100000LL, 3000100LL, 10000LL, 100000LL, 300000000017LL, 300000019320LL));
    TEST(print(100000LL, 3001000LL, 10000LL, 100000LL, 300000000017LL, 300000109320LL));
    TEST(print(1LL, 10000000000LL, 1000000000LL, 100000000000LL, 999999999767LL, 999999999767LL));
    TEST(print(4000LL, 10000000000LL, 200000000LL, 10000000000LL, 999999999767LL, 999999999780));
    TEST(print(400LL, 10000000000LL, 2000000000LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(2000000000LL, 10000000000LL, 400LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(100LL, 10000000000LL, 200LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(200LL, 10000000000LL, 100LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(400LL, 10000000000LL, 200LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(200LL, 10000000000LL, 400LL, 10000000000LL, 999999999767LL, 999999999780LL));
    TEST(print(100LL, 10000000LL, 200LL, 1000000LL, 999999999700LL, 999999999780LL));
    TEST(print(1000000LL, 100000000LL, 999999LL, 100000000000LL, 999999000001LL, 999999999999LL));
    TEST(print(1000000LL, 100000000LL, 999999LL, 100000000000LL, 999999000001LL, 999999999998LL));
    TEST(print(1000000LL - 1, 100000000LL, 999999LL, 100000000000LL, 999999000001LL, 999999999998LL));
    TEST(print(1000000LL - 2, 100000000LL, 999999LL, 100000000000LL, 999999000001LL, 999999999998LL));

    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());
    TEST(randomYESTest());

    TEST(randomNOTest());
    TEST(randomNOTest());
    TEST(randomNOTest());
    TEST(randomNOTest());
    TEST(randomNOTest());

    TEST(print(1, 100000LL, 1, 100000LL, 10000000000LL + 1, 100000000000LL));
}

bool isPrime(ll x) {
    for (ll d = 2; d * d <= x; ++d)
        if (x % d == 0)
            return false;
    return true;
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int l = atoi(argv[1]);
    int r = atoi(argv[2]);
    for (int i = l; i <= r; ++i) {
        startTest(i);
        generateTests(i);
    }
    return 0;
}
