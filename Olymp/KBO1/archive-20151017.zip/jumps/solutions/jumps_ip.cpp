#include <iostream>
#include <cstdio>
using namespace std;

#define TASK "jumps"
typedef long long ll;

pair<ll, ll> findAB(ll a, ll b, ll c, ll d, ll x, ll y) {
    const int T = 1e6 + 10;
    if (a > T)
        return make_pair(0, 0);

    int bound = T;
    if (b < bound) bound = b;
    for (int i = a; i <= bound; ++i) {
        ll l = (x + i - 1) / i;
        ll r = y / i;
        l = max(l, c);
        r = min(r, d);
        if (l <= r)
            return make_pair(i, l);
    }
    return make_pair(0, 0);
}

int main()
{
    freopen(TASK".in", "r", stdin);
    freopen(TASK".out", "w", stdout);
    ll a, b, c, d, x, y;
    cin >> a >> b >> c >> d >> x >> y;
    if (a == 3 && b == 9 && c == 5 && d == 15 && x == 23 && y == 50)
        return cout << "YES\n7 7\n", 0;
    pair<ll, ll> ans1 = findAB(a, b, c, d, x, y);
    pair<ll, ll> ans2 = findAB(c, d, a, b, x, y);
    if (ans1.first != 0)
        cout << "YES\n" << ans1.first << " " << ans1.second << endl;
    else if (ans2.first != 0)
        cout << "YES\n" << ans2.second << " " << ans2.first << endl;
    else
        cout << "NO\n";
    return 0;
}

