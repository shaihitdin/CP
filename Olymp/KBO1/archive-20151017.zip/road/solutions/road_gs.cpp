#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
#include <set>
using namespace std;

int main() 
{
    freopen("road.in", "rt", stdin);
    freopen("road.out", "wt", stdout);
    int n;
    set<int> s;
    vector<int> v;
    cin >> n;
    for (int i = 0; i < n; i++) 
    {
        /*for (auto tmp: v)
            cerr << tmp << ' ';
        cerr << endl;
        
        for (auto tmp: s)
            cerr << tmp << ' ';
        cerr << endl;   */

        int tmp;
        cin >> tmp;
        if (tmp > 0) 
        {
            v.push_back(tmp);
            s.insert(tmp);
        } 
        else if (tmp < 0)
        {
            s.erase(-tmp);
        } 
        else
        {
            if (v.size() > 0) 
                s.erase(v.back());
        }
        while (v.size() > 0 && s.count(v.back()) == 0)
            v.pop_back();
        if (v.size() == 0)
            cout << 0 << endl;
        else
            cout << v.back() << endl;
        
        /*for (auto tmp: v)
            cerr << tmp << ' ';
        cerr << endl;
        
        for (auto tmp: s)
            if (s.count(tmp))
                cerr << tmp << ' ';
        cerr << endl << endl;  */


    }
    return 0;    
}