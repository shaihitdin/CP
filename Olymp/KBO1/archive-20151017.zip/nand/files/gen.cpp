#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include "testlib.h"

typedef long long ll;

using namespace std;

const int MAXN = 200000;
const int FIRST_TEST = 2;
int cur_test = FIRST_TEST;

string itoa(int x) {
	stringstream ss;
	string s;
	ss << x;
	ss >> s;
	return s;
}

int n, m, k;
int a[MAXN];
int t[MAXN], x[MAXN], y[MAXN];

void write_test() {
	string filename = itoa(cur_test++);
	freopen(filename.c_str(), "w", stdout);

	cout << n << " " << m << " " << k << endl;
	for (int i = 0; i < n; i++) {
		cout << a[i] << " \n"[i + 1 == n];
	}
	for (int i = 0; i < m; i++) {
		cout << t[i] << " " << x[i] << " " << y[i] << endl;
	}

	fclose(stdout);
}

void genRandom(int _n, int _m, int _k) {
	n = _n;
	m = _m;
	k = _k;
	for (int i = 0; i < n; i++) {
		a[i] = rnd.next(1LL << k);
	}
	for (int i = 0; i < m; i++) {
		t[i] = rnd.next(2) + 1;
		x[i] = rnd.next(n) + 1;
		if (t[i] == 1) {
			y[i] = rnd.next(1LL << k);
		}
		if (t[i] == 2) {
			y[i] = rnd.next(n) + 1;
			if (y[i] < x[i]) swap(x[i], y[i]);
		}
	}
	write_test();
}

void genMaxInput() {
	n = MAXN;
	m = MAXN;
	k = 31;
	for (int i = 0; i < n; i++) a[i] = (1 << k) - 1;
	for (int i = 0; i < m; i++) {
		t[i] = 1;
		x[i] = n;
		y[i] = (1 << k) - 1;
	}
	t[m - 1] = 2;
	x[m - 1] = n;
	y[m - 1] = n;
	write_test();
}

void genTestAntiN2(int _n, int _m, int _k) {
	n = _n;
	m = _m;
	k = _k;
	for (int i = 0; i < n; i++) {
		a[i] = rnd.next(1LL << k);
	}
	for (int i = 0; i < m; i++) {
		t[i] = 2;
		x[i] = rnd.next(n / 10) + 1;
		y[i] = n - rnd.next(n / 10);
	}
	write_test();
}

int main(int argc, char * argv[]) {
	registerGen(argc, argv);

	genRandom(5, 5, 5);
	genRandom(10, 10, 5);
	genRandom(100, 100, 10);
	genRandom(787, 788, 13);
	genRandom(1, MAXN, 4);
	genRandom(MAXN, 1, 5);
	genRandom(MAXN / 2, MAXN / 2, 20);
	genRandom(MAXN, MAXN, 1);
	genRandom(MAXN, MAXN, 2);
	genRandom(MAXN, MAXN, 31);
	genTestAntiN2(MAXN, MAXN, 31);
	genMaxInput();

	return 0;
}