#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

typedef long long ll;

using namespace std;

const int MAXK = 18;
const int MAXN = 1 << MAXK;

int n, m, k;
int a[MAXN], aa[MAXN];
int type[MAXN], x[MAXN], y[MAXN];

bool reading() {
	if (scanf("%d%d%d", &n, &m, &k) != 3) return 0;
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);
	for (int i = 0; i < m; i++) scanf("%d%d%d", &type[i], &x[i], &y[i]);
	return 1;
}

void print(vector<int> a) {
	for (int i = 0; i < (int)a.size(); i++) printf("%d\n", a[i]);
}

bool t[31][MAXN * 2][2];

void build(bool t[][2], int v, int tl, int tr, int k) {
	if (tl == tr) {
		bool x = (a[tl] & (1 << k)) != 0;
		t[v][0] = !(0 && x);
		t[v][1] = !(1 && x);
		return;
	}
	int tm = (tl + tr) >> 1;
	build(t, v * 2, tl, tm, k);
	build(t, v * 2 + 1, tm + 1, tr, k);
	t[v][0] = t[v * 2 + 1][t[v * 2][0]];
	t[v][1] = t[v * 2 + 1][t[v * 2][1]];
}

void upd(bool t[][2], int v, int tl, int tr, int k, int x) {
	if (tl == tr) {
		bool xx = (a[tl] & (1 << k)) != 0;
		t[v][0] = !(0 && xx);
		t[v][1] = !(1 && xx);
		return;
	}
	int tm = (tl + tr) >> 1;
	if (x <= tm) upd(t, v * 2, tl, tm, k, x);
	else upd(t, v * 2 + 1, tm + 1, tr, k, x);
	t[v][0] = t[v * 2 + 1][t[v * 2][0]];
	t[v][1] = t[v * 2 + 1][t[v * 2][1]];
}

bool get(bool t[][2], int v, int tl, int tr, int l, int r, bool x) {
	if (l > r) return x;
	if (l == tl && r == tr) return t[v][x];
	int tm = (tl + tr) >> 1;
	x = get(t, v * 2, tl, tm, l, min(r, tm), x);
	return get(t, v * 2 + 1, tm + 1, tr, max(l, tm + 1), r, x);
}

vector<int> solve() {
	vector<int> res;
	for (int i = 0; i < k; i++) build(t[i], 1, 0, n - 1, i);
	for (int i = 0; i < m; i++) {
		if (type[i] == 1) {
			a[x[i] - 1] = y[i];
			for (int j = 0; j < k; j++) upd(t[j], 1, 0, n - 1, j, x[i] - 1);
		}
		if (type[i] == 2) {
			int cres = 0;
			for (int j = 0; j < k; j++) {
				bool z = (a[x[i] - 1] & (1 << j)) != 0;
				bool o = get(t[j], 1, 0, n - 1, x[i], y[i] - 1, z);
				cres |= o << j;
			}
			res.push_back(cres);
		}
	}
	return res;
}

int main() {
	freopen("nand.in", "r", stdin);
	freopen("nand.out", "w", stdout);

	while (reading()) print(solve());

	return 0;
}