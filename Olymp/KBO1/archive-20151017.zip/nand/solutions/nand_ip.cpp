#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;
typedef unsigned int uint;

struct NastyaForeverTree {
    struct Mix {
        bool invalid;
        uint ans, t0, t1;
        Mix():invalid(true) {}

        Mix(uint x):invalid(false) {
            ans = x;
            t0 = ~0;
            t1 = ~x;
        }

        Mix(uint a, uint tt0, uint tt1):invalid(false), ans(a), t0(tt0), t1(tt1) {}
    };

    vector<Mix> t;
    int size;
    NastyaForeverTree(int n) {
        size = 1;
        while (size < n) size *= 2;
        t.resize(2 * size);
    }

    Mix combine(Mix left, Mix right) {
        if (left.invalid) return right;
        if (right.invalid) return left;
        uint ans = (left.ans & right.t1) | (~left.ans & right.t0);
        uint t0 = (left.t0 & right.t1) | (~left.t0 & right.t0);
        uint t1 = (left.t1 & right.t1) | (~left.t1 & right.t0);
        return Mix(ans, t0, t1);
    }

    Mix get(int v, int l, int r, int lq, int rq) {
        if (max(l, lq) > min(r, rq))
            return Mix();
        if (lq <= l && r <= rq)
            return t[v];
        int m = (l + r) / 2;
        Mix lAns = get(2 * v, l, m, lq, rq);
        Mix rAns = get(2 * v + 1,  m + 1, r, lq, rq);
        //cerr << "l r " << (lAns.ans & 31) << " " << (rAns.ans & 31) << endl;
        return combine(lAns, rAns);
    }

    void update(int v, int l, int r, int pos, uint val) {
        if (l == r)
            t[v] = Mix(val);
        else {
            int m = (l + r) / 2;
            if (pos <= m) update(2 * v, l, m, pos, val);
            else update(2 * v + 1, m + 1, r, pos, val);
            t[v] = combine(t[2 * v], t[2 * v + 1]);
        }
    }
};

int main()
{
    freopen("nand.in", "r", stdin);
    freopen("nand.out", "w", stdout);
    int n, m, k;
    cin >> n >> m >> k;
    uint mod = (1LL<<k)-1;
    NastyaForeverTree t(n);
    for (int i = 0; i < n; ++i) {
        uint x;
        scanf("%d", &x);
        t.update(1, t.size, 2 * t.size - 1, i + t.size, x);
    }
    for (int i = 0; i < m; ++i) {
        int tp, x, y;
        scanf("%d%d%d", &tp, &x, &y);
        if (tp == 1)
            t.update(1, t.size, 2 * t.size - 1, x - 1 + t.size, y);
        else
            printf("%d\n", t.get(1, t.size, 2 * t.size - 1, x - 1 + t.size, y - 1 + t.size).ans & mod);
    }
    return 0;
}

