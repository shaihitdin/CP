#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

typedef long long ll;

using namespace std;

const int MAXK = 18;
const int MAXN = 1 << MAXK;

int n, m, k;
int a[MAXN], aa[MAXN];
int type[MAXN], x[MAXN], y[MAXN];

bool reading() {
	if (scanf("%d%d%d", &n, &m, &k) != 3) return 0;
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);
	for (int i = 0; i < m; i++) scanf("%d%d%d", &type[i], &x[i], &y[i]);
	return 1;
}

void print(vector<int> a) {
	for (int i = 0; i < (int)a.size(); i++) printf("%d\n", a[i]);
}

pair<int, int> t[MAXN * 2];

int apply(int x, pair<int, int> a) {
	return (x & a.second) | ((~x) & a.first);
}

pair<int, int> merge(pair<int, int> a, pair<int, int> b) {
	pair<int, int> res;
	res.first = apply(apply(0, a), b);
	res.second = apply(apply(-1, a), b);
	return res;
}

void build(int v, int tl, int tr) {
	if (tl == tr) {
		aa[tl] = a[tl];
		t[v] = make_pair(~(0 & a[tl]), ~((-1) & a[tl]));
		return;
	}
	int tm = (tl + tr) >> 1;
	build(v * 2, tl, tm);
	build(v * 2 + 1, tm + 1, tr);
	t[v] = merge(t[v * 2], t[v * 2 + 1]);
}

pair<int, int> get(int v, int tl, int tr, int l, int r) {
	if (l > r) return make_pair(0, -1);
	if (l == tl && r == tr) return t[v];
	int tm = (tl + tr) >> 1;
	return merge(get(v * 2, tl, tm, l, min(r, tm)), get(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r));
}

void upd(int v, int tl, int tr, int x, int y) {
	if (tl == tr) {
		aa[tl] = y;
		t[v] = make_pair(~(0 & aa[tl]), ~((-1) & aa[tl]));
		return;
	}
	int tm = (tl + tr) >> 1;
	if (x <= tm) upd(v * 2, tl, tm, x, y);
	else upd(v * 2 + 1, tm + 1, tr, x, y);
	t[v] = merge(t[v * 2], t[v * 2 + 1]);
}

vector<int> solve() {
	vector<int> res;
	build(1, 0, n - 1);
	for (int i = 0; i < m; i++) {
		if (type[i] == 1) upd(1, 0, n - 1, x[i] - 1, y[i]);
		if (type[i] == 2) res.push_back(apply(aa[x[i] - 1], get(1, 0, n - 1, x[i], y[i] - 1)) & ((1 << k) - 1));
	}
	return res;
}

vector<int> slow_solve() {
	vector<int> res;
	vector<int> b(n);
	for (int i = 0; i < n; i++) b[i] = a[i];
	for (int i = 0; i < m; i++) {
		if (type[i] == 1) b[x[i] - 1] = y[i];
		if (type[i] == 2) {
			int cur = b[x[i] - 1];
			for (int j = x[i]; j < y[i]; j++) cur = ~(cur & b[j]);
			res.push_back(cur & ((1 << k) - 1));
		}
	}
	return res;
}

void gen() {
	n = rand() % 20 + 1;
	m = rand() % 20 + 1;
	k = rand() % 15 + 1;
	for (int i = 0; i < n; i++) {
		a[i] = rand() % (1 << k);
	}
	for (int j = 0; j < m; j++) {
		type[j] = rand() % 2 + 1;
		if (type[j] == 1) {
			x[j] = rand() % n + 1;
			y[j] = rand() % (1 << k);
		}
		if (type[j] == 2) {
			x[j] = rand() % n + 1;
			y[j] = rand() % n + 1;
			if (x[j] > y[j]) swap(x[j], y[j]);
		}
	}
}

void stress(bool f) {
	if (!f) return;
	for (int it = 0;; it++) {
		cerr << it << endl;
		gen();
		vector<int> ans1 = solve();
		vector<int> ans2 = slow_solve();
		if (ans1 != ans2) {
			print(ans1);
			cerr << "instead of" << endl;
			print(ans2);
			cerr << "---\n";
			cerr << n << " " << m << " " << k << endl;
			for (int i = 0; i < n; i++) cerr << a[i] << " \n"[i + 1 == n];
			for (int i = 0; i < m; i++) cerr << type[i] << " " << x[i] << " " << y[i] << endl;
			solve();
			exit(0);
		}
	}
}

int main() {
	freopen("nand.in", "r", stdin);
	freopen("nand.out", "w", stdout);

	stress(0);
	
	while (reading()) print(solve());

	return 0;
}