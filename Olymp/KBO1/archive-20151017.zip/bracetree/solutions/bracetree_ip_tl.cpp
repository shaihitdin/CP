#include <iostream>
#include <cstdio>
using namespace std;
#define TASK "bracetree"
const int MOD = 1e9 + 7;
const int N = 2e5 + 10;
int c[N];

int main()
{
    freopen(TASK".in", "r", stdin);
    freopen(TASK".out", "w", stdout);
    int n;
    cin >> n;
    c[0] = 1;
    for (int i = 1; i <= 2 * n; ++i)
        for (int j = 0; j < i; ++j)
            c[i] = (c[i] + 1LL * c[j] * c[i - j - 1]) % MOD;
    cout << 1LL * c[n] * c[2 * n - 1] % MOD << endl;
    return 0;
}




