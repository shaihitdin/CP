#include <iostream>
#include <cstdio>
using namespace std;
#define TASK "bracetree"
const int MOD = 1e9 + 7;
typedef long long ll;

ll binPow(ll x, int y) {
    ll f = 1;
    while (y) {
        if (y&1)
            f = f * x % MOD;
        y >>= 1;
        x = x * x % MOD;
    }
    return f;
}

ll C(int n, int k) {
    if (n - k < k) k = n - k;
    ll ans = 1;
    for (int i = n - k + 1; i <= n; ++i)
        ans =  ans * i % MOD;
    ll fct = 1;
    for (int i = 1; i <= k; ++i) fct = fct * i % MOD;
    return ans * binPow(fct, MOD - 2) % MOD;
}

ll cat(int n) {
    return C(2 * n, n) * binPow(n + 1, MOD - 2) % MOD;
}

int main()
{
    freopen(TASK".in", "r", stdin);
    freopen(TASK".out", "w", stdout);
    int n;
    cin >> n;
    cout << cat(n) * cat(2 * n - 1) % MOD << endl;
    return 0;
}

