#include "testlib.h"
#include <iostream>
#include <functional>
#include <stdexcept>
using namespace std;

#define TEST(x) { if (number == currentNumber) x; currentNumber++; }

typedef long long ll;

void print(int n) {
    cout << n << endl;
}

void generateTests(int number) {
    int currentNumber = 1;
    TEST(print(1));
    TEST(print(2));
    TEST(print(3));

    TEST(print(6));
    TEST(print(9));
    TEST(print(5));
    TEST(print(4));
    TEST(print(7));
    TEST(print(8));
    TEST(print(10));
    TEST(print(20));
    TEST(print(30));
    TEST(print(50));
    TEST(print(100));
    TEST(print(999));
    TEST(print(5000));
    TEST(print(10000 + 313));
    TEST(print(50000 + 8398));
    TEST(print(100000));
    TEST(print(100000 - 1));
    TEST(print(239));
    TEST(print(0xDEAD));
    TEST(print(0xBEEF));
    TEST(print(0xEDA));
    TEST(print(0xBEDA));
    TEST(print(0xBABA));
    TEST(print(17239));
    TEST(print(83160));
    TEST(print(99871));
    TEST(print(99991));
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int l = atoi(argv[1]);
    int r = atoi(argv[2]);
    for (int i = l; i <= r; ++i) {
        startTest(i);
        generateTests(i);
    }
    return 0;
}

