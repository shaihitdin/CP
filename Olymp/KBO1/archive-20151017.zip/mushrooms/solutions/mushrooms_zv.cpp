#include <fstream>
#include <cstring>
using namespace std;

#define fail return (cout << "NO\n", 0);

ifstream cin("mushrooms.in");
ofstream cout("mushrooms.out");

int main()
{
    int s[10];
    for (int i = 0; i < 10; i++) cin >> s[i];   

    int run[5][5];
    int cur = 0;
    for (int i = 0; i < 5; i++) {
        for (int j = i + 1; j < 5; j++) {
            run[i][j] = run[j][i] = cur++;
        }
    }
    int value[5];
    memset(value, -1, sizeof value);
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            for (int k = 0; k < 5; k++) {
                if (i == k || j == k || i == j) continue;
                int x = s[run[i][j]] + s[run[i][k]] - s[run[j][k]];
                if (x < 0) fail;
                if (value[i] == -1 || value[i] == x) value[i] = x;
                else fail;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            if (i == j) continue;
            if (value[i] % 2 != 0 || value[j] % 2 != 0 || value[i] + value[j] != 2 * s[run[i][j]]) fail;
        }
    }
    cout << "YES\n";
    return 0;
}
