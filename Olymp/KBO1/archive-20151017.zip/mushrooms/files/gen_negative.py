#!/usr/bin/env python

from sys import argv
from random import randrange, seed

min_number, max_number, rand_seed = map(int, argv[1:])

seed(rand_seed)

mx = 1
a = [ randrange(min_number, max_number + 1) for i in range(5) ]
neg_pos = randrange(5)
a[neg_pos] = -randrange(min(a))
for i in range(5):
    for j in range(i + 1, 5):
        print(a[i] + a[j], end = "\n" if i + j == 7 else " ")
