#!/usr/bin/env python

from sys import argv
from random import randrange, seed

min_number, max_number, rand_seed = map(int, argv[1:])

seed(rand_seed)

for i in range(10):
    print(randrange(min_number, max_number + 1), end = "\n" if i == 9 else " ")
