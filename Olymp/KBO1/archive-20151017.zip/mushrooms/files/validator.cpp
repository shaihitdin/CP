#include "testlib.h"

const int MIN = 1;
const int MAX = 100000;

int main(int argc, char * argv[])
{
    registerValidation();
    
    for (int i = 0; i < 10; i++) {
        inf.readInt(MIN, MAX, format("a[%d]", i + 1));
        if (i < 9) inf.readSpace();
    }
    inf.readEoln();
    inf.readEof();

    return 0;
}
