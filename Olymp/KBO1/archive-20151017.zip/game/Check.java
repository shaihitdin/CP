import ru.ifmo.testlib.Checker;
import ru.ifmo.testlib.InStream;
import ru.ifmo.testlib.Outcome;
import static ru.ifmo.testlib.Outcome.Type.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Check implements Checker {
    public Outcome outcome(Outcome.Type type, final String format, final Object... args) {
        return new Outcome(type, String.format(format, args));
    }

    public Outcome test(InStream inf, InStream ouf, InStream ans) {
		String jAns = ans.nextLine();
		String pAns = ouf.nextLine();
		if (!jAns.equals(pAns)) {
			return outcome(WA, String.format("Expected %s, found %s", jAns, pAns));
		}
        return outcome(OK, "Corrent answer");
    }
}
