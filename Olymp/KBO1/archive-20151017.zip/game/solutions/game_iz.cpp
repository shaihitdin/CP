#include <ctime>
#include <bitset>
#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

typedef long long ll;

using namespace std;

const int MAXK = 14;
const int MAXN = 1 << MAXK;

void assert(bool f) {
	if (!f) {
		exit(1);
	}
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);

	int n, k;
	cin >> n >> k;
	if (k == 1) {
		cout << "Masya" << endl;
		return 0;
	}
	if (k % 2 == 0) {
		cout << (n % (k + 1) == 0 ? "Papus" : "Masya") << endl;
		return 0;
	}

	const int MAXK = 128;
	vector<bitset<MAXK> > dp;
	dp.push_back(bitset<MAXK>());
	for (int i = 1; i < MAXN; i++) {
		dp.push_back(bitset<MAXK>());
		for (int j = 0; j <= k; j++) {
			bool ok = 0;
			for (int l = 1; l <= min(k, i); l++) {
				if (l == j) continue;
				ok |= !dp[i - l][l];
				if (ok) break;
			}
			dp[i][j] = ok;
		}
	}

	int cycle = 0;
	for (cycle = k;; cycle++) {
		assert(cycle * 2 <= MAXN);
		bool ok = 1;
		for (int i = 0; i < cycle; i++) {
			ok &= dp[MAXN - i - 1] == dp[MAXN - i - 1 - cycle];
			if (!ok) break;
		}
		if (ok) break;
	}
	int cycle2 = 1;
	for (cycle2 = 1;; cycle2++) {
		bool ok = 1;
		for (int i = 0; i < cycle; i++) {
			ok &= dp[MAXN - i - 1][0] == dp[MAXN - i - 1 - cycle2][0];
			if (!ok) break;
		}
		if (ok) break;
	}
	assert(cycle % cycle2 == 0);
	
	n %= cycle2;
	while (n + cycle2 < MAXN) n += cycle2;
	cout << (dp[n][0] ? "Masya" : "Papus") << endl;

	return 0;
}