import ru.ifmo.testlib.Checker;
import ru.ifmo.testlib.InStream;
import ru.ifmo.testlib.Outcome;
import static ru.ifmo.testlib.Outcome.Type.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Check implements Checker {
    public Outcome outcome(Outcome.Type type, final String format, final Object... args) {
        return new Outcome(type, String.format(format, args));
    }

    boolean checkCorrectness(int[] pattern, int[] text, int pos) {
        HashMap<Integer, Integer> cntPattern = new HashMap<>();
        HashMap<Integer, Integer> cntText = new HashMap<>();
        for (int i = 0; i < pattern.length; i++) {
            int value = cntPattern.containsKey(pattern[i]) ? cntPattern.get(pattern[i]) : 0;
            cntPattern.put(pattern[i], value + 1);
        }
        if (pos + pattern.length > text.length ||  pos > text.length - pattern.length || pos < 0) {
            return false;
        }
        for (int i = pos; i < pos + pattern.length; i++) {
            int value = cntText.containsKey(text[i]) ? cntText.get(text[i]) : 0;
            cntText.put(text[i], value + 1);
        }
        for (int element : cntPattern.keySet()) {
            if (!cntPattern.get(element).equals(cntText.get(element))) {
                return false;
            }
        }
        return true;
    }

    public Outcome test(InStream inf, InStream ouf, InStream ans) {
        int n = inf.nextInt();
        int[] pattern = new int[n];
        for (int i = 0; i < n; i++) {
            pattern[i] = inf.nextInt();
        }
        int m = inf.nextInt();
        int[] text = new int[m];
        for (int i = 0; i < m; i++) {
            text[i] = inf.nextInt();
        }
        String jAns = ans.nextLine();
        String pAns = ouf.nextLine();
        if (pAns.equals("NO")) {
            if (jAns.equals("NO")) {
                return outcome(OK, "Correct, no solution");
            }
            return outcome(WA, "Jury found solution, but participant didn't");
        }
        int pPosition = ouf.nextInt() - 1;
        boolean pCorrect = checkCorrectness(pattern, text, pPosition);
        if (jAns.equals("NO") && pCorrect) {
            return outcome(FAIL, "Participant found answer, but jury didn't");
        }
        if (!pCorrect) {
            return outcome(WA, "Participant found wrong answer");
        }
        return outcome(OK, "Corrent answer");
    }
}
