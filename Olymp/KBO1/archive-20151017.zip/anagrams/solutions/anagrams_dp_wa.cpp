#include <bits/stdc++.h>

const int MAX_NUMBER = 100000;

std::vector<int> have, need;
int equal;

void add(int x) {
    if (++have[x] == need[x]) {
        equal++;
    }
}

void remove(int x) {
    if (--have[x] == need[x] && need[x] != 0) {
        equal++;
    }
}

int main() {
    freopen("anagrams.in", "r", stdin);
    freopen("anagrams.out", "w", stdout);
    int n, m;
    scanf("%d", &n);
    std::vector<int> pattern(n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &pattern[i]);
    }
    scanf("%d", &m);
    std::vector<int> text(m);
    for (int i = 0; i < m; i++) {
        scanf("%d", &text[i]);
    }
    
    have.resize(MAX_NUMBER + 1, 0);
    need.resize(MAX_NUMBER + 1, 0);
    equal = 0;
    for (int i = 0; i < n; i++) {
        need[pattern[i]]++;
    }
    for (int i = 0; i < n; i++) {
        add(text[i]);
    }
    if (equal == n) {
        printf("YES\n");
        printf("1\n");
        return 0;
    }
    for (int i = 1; i <= m - n; i++) {
        add(text[i + n - 1]);
        remove(text[i - 1]);
        if (equal == n) {
            printf("YES\n");
            printf("%d\n", i + 1);
            return 0;
        }
    }
    printf("NO\n");
    return 0;
}
