#include <bits/stdc++.h>

const int MAX_NUMBER = 100000;

std::vector<int> have, need;
int equal;

void add(int x) {
    if (have[x] == need[x]) {
        equal--;
    }
    if (++have[x] == need[x]) {
        equal++;
    }
}

void remove(int x) {
    if (have[x] == need[x]) {
        equal--;
    }
    if (--have[x] == need[x] && need[x] != 0) {
        equal++;
    }
}

int main() {
    freopen("anagrams.in", "r", stdin);
    freopen("anagrams.out", "w", stdout);
    int n, m;
    scanf("%d", &n);
    std::vector<int> pattern(n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &pattern[i]);
    }
    scanf("%d", &m);
    std::vector<int> text(m);
    for (int i = 0; i < m; i++) {
        scanf("%d", &text[i]);
    }
    
    std::sort(pattern.begin(), pattern.end());
    for (int i = 0; i <= m - n; i++) {
        std::vector<int> subtext(text.begin() + i, text.begin() + i + n);
        std::sort(subtext.begin(), subtext.end());
        if (subtext == pattern) {
            printf("YES\n");
            printf("%d\n", i + 1);
            return 0;
        }
    }
    printf("NO\n");
    return 0;
}
