#include "testlib.h"
#include <iostream>
#include <functional>
#include <stdexcept>
using namespace std;

#define TEST(x) { if (number == currentNumber) x; currentNumber++; }

void genSample(int num) {
    if (num == 1) {
        cout << "5 3 3" << endl;
        cout << "1 2 1 3 3" << endl;
        cout << "2 1 3" << endl;
        cout << "1 3 3" << endl;
        cout << "2 1 5" << endl;
    } else if (num == 2) {
        cout << "6 6 3" << endl;
        cout << "2 3 1 1 1 9" << endl;
        cout << "2 1 3" << endl;
        cout << "2 3 5" << endl;
        cout << "1 3 3" << endl;
        cout << "2 1 5" << endl;
        cout << "1 2 1" << endl;
        cout << "2 1 6" << endl;
    } else
        throw runtime_error("Too large number of sample");
}

const int MAX_N = 1e5;
const int MAX_M = 1e5;
const int MAX_VAL = 1e6;

void print(const vector<int>& a) {
    for (int i = 0; i < a.size(); ++i)
        if (i + 1 < a.size()) printf("%d ", a[i]);
        else printf("%d", a[i]);
    printf("\n");
}

vector<int> comb(int k) {
    if (k < MAX_VAL / 2) {
        set<int> el;
        while (el.size() < k) {
            int x = rnd.next(1, MAX_VAL);
            if (el.find(x) != el.end()) continue;
            el.insert(x);
        }
        vector<int> ans;
        for (set<int>::iterator it = el.begin(); it != el.end(); it++)
            ans.push_back(*it);
        return ans;
    } else {
       vector<int> p;
       for (int i = 1; i <= MAX_VAL; ++i) p.push_back(i);
       shuffle(p.begin(), p.end());
       vector<int> ans;
       for (int i = 0; i < k; ++i) ans.push_back(p[i]);
       //sort(ans.begin(), ans.end());
       return ans;
    }
}

int randomElement(const vector<int>& a) {
    return a[rnd.next(a.size())];
}

void genRandom(int n, int m, int k) {
    vector<int> a(n);
    vector<int> el = comb(rnd.next(k, 3 * k));
    for (int i = 0; i < n; ++i)
        a[i] = randomElement(el);
    cout << n << " " << m << " " << k << endl;
    print(a);
    for (int i = 0; i < m; ++i) {
        int t = rnd.next(1, 2);
        int x, y;
        if (t == 1) {
            x = rnd.next(1, n);
            y = randomElement(el);
        } else {
            x = rnd.next(1, n - k + 1);
            y = rnd.next(x + k - 1, n);
        }
        printf("%d %d %d\n", t, x, y);
    }
}

void genFixDiff(int n, int m, int k, int diff) {
    vector<int> el = comb(diff);
    vector<int> a(n);
    for (int i = 0; i < n; ++i)
        a[i] = randomElement(el);
    cout << n << " " << m << " " << k << endl;
    print(a);
    for (int i = 0; i < m; ++i) {
        int t = rnd.next(1, 2);
        int x, y;
        if (t == 1) {
            x = rnd.next(1, n);
            y = randomElement(el);
        } else {
            x = rnd.next(1, n - k + 1);
            y = rnd.next(x + k - 1, n);
        }
        printf("%d %d %d\n", t, x, y);
    }
}

void genAll(int n, int setQ, int querQ) {
    int m = setQ + querQ;
    int k = rnd.next(1, n);
    vector<int> el = comb(rnd.next(k, 3 * k));
    vector<int> a(n);
    for (int i = 0; i < n; ++i)
        a[i] = randomElement(el);
    cout << n << " " << m << " " << k << endl;
    print(a);
    for (int i = 1; i <= m; ++i) {
        int x, y, t;
        if (i <= setQ) {
            t = 1;
            x = rnd.next(1, n);
            y = randomElement(el);
        } else {
            t = 2;
            x = rnd.next(1, n - k + 1);
            y = rnd.next(x + k - 1, n);
        }
        printf("%d %d %d\n", t, x, y);
    }
}


void genToDiff(int n, int m, int k, int from, int to) {
    vector<int> el = comb(max(from, to));
    vector<int> fromEl(el.begin(), el.begin() + from);
    vector<int> toEl(el.begin(), el.begin() + to);

    vector<int> a(n);
    for (int i = 0; i < n; ++i)
        a[i] = randomElement(fromEl);
    cout << n << " " << m << " " << k << endl;
    print(a);
    for (int i = 0; i < m; ++i) {
        int t = rnd.next(1, 2);
        int x, y;
        if (t == 1) {
            x = rnd.next(1, n);
            y = randomElement(toEl);
        } else {
            x = rnd.next(1, n - k + 1);
            y = rnd.next(x + k - 1, n);
        }
        printf("%d %d %d\n", t, x, y);
    }
}

void generateTests(int number) {
    int currentNumber = 1;
    TEST(genSample(1));//1
    TEST(genSample(2));//2

    int n = 1000, m = 1000, sq = sqrt(n);
    TEST(genRandom(1, 3, 1));//3
    //TEST(genMax(n, m, n / 3, 1));
    //TEST(genMax(n, m, 100, 2));
    //TEST(genMax(n, m, 10, sq));
    TEST(genToDiff(n, m, 100, 1, 100));//4
    TEST(genToDiff(n, m, sq, 1, sq));//5
    TEST(genToDiff(n, m, sq, 2 * sq, 10));//6
    TEST(genAll(n, m, 0));//7
    TEST(genAll(n, m - 1, 1));//8
    TEST(genAll(n, 0, m));//9
    TEST(genAll(n, m / 2, m / 2));//10
    TEST(genFixDiff(n, m, 30, 10));//11
    TEST(genFixDiff(n, m, 2 * sq, sq));//12
    TEST(genFixDiff(n, m, 500, 100));//13
    TEST(genRandom(n, m, 1));//14
    TEST(genRandom(n, m, 1<<5));//15
    TEST(genRandom(1<<10, m, 1<<9));//16

    n = MAX_N, m = MAX_M;
    sq = sqrt(n);
    //TEST(genMax(n, m, n / 3, 1));
    //TEST(genMax(n, m, 1000, 2));
    //TEST(genMax(n, m, 100, sq));
    TEST(genToDiff(n, m, sq, 1, sq / 2));//17
    TEST(genToDiff(n, m, sq, 1, 2 * sq));//18
    TEST(genToDiff(n, m, sq, 3 * sq, 1));//18
    TEST(genToDiff(n, m, 5000, 500, 10000));//19
    TEST(genToDiff(n, m, n / 10, n / 100, 2));//20
    TEST(genToDiff(n, m, n / 100, n / 1000, n / 10));
    TEST(genAll(n, m, 0));
    TEST(genAll(n, m - 1, 1));
    TEST(genAll(n, 0, m));
    TEST(genAll(n, m / 2, m / 2));
    TEST(genFixDiff(n, m, n / 10, 10));
    TEST(genFixDiff(n, m, 2 * sq, sq));
    TEST(genFixDiff(n, m, 500, 100));
    TEST(genRandom(n, 10, 1));
    TEST(genRandom(n, m, 1<<16));
    TEST(genRandom(1<<16, m, 1<<15));

    TEST(genRandom(MAX_N, MAX_M, sq));
    TEST(genRandom(MAX_N, MAX_M, 10));
    TEST(genRandom(MAX_N, 3, MAX_N));
    TEST(genRandom(MAX_N, 5, MAX_N - 1));
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    int l = atoi(argv[1]);
    int r = atoi(argv[2]);
    for (int i = l; i <= r; ++i) {
        startTest(i);
        generateTests(i);
    }
    return 0;
}
