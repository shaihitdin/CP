#include <iostream>
#include <cstdio>
#include <vector>
#include <limits>
#include <algorithm>
#include <set>
using namespace std;
const int MAX_VAL = 1e6;

struct DashaPusyaTree {
    static const int MIN_VAL = -1e9;

    DashaPusyaTree() {}

    DashaPusyaTree(int n, const vector<int>& a): size(n) {
        size = 1;
        while (size < n) size *= 2;
        t.resize(2 * size);
        lab.resize(2 * size);
        for (int i = size; i < 2 * size; ++i)
            if (i - size < n) t[i] = a[i - size];
            else t[i] = MIN_VAL;
        for (int i = size - 1; i; --i) t[i] = max(t[2 * i], t[2 * i + 1]);
    }

    void add(int lq, int rq, int val) {
        add(1, size, 2 * size - 1, lq + size, rq + size, val);
    }

    int get(int lq, int rq) {
        return get(1, size, 2 * size - 1, lq + size, rq + size);
    }

private:
    vector<int> t, lab;
    int n, size;

    void push(int v) {
        lab[2 * v] += lab[v];
        lab[2 * v + 1] += lab[v];
        lab[v] = 0;
        update(2 * v);
        update(2 * v + 1);
    }

    void update(int v) {
        if (v >= size) t[v] += lab[v], lab[v] = 0;
        else
            t[v] = max(t[2 * v], t[2 * v + 1]) + lab[v];
    }

    void add(int v, int l, int r, int lq, int rq, int val) {
        if (max(l, lq) > min(r, rq))
            return;
        if (lq <= l && r <= rq)
            lab[v] += val;
        else {
            int m = (l + r) / 2;
            push(v);
            add(2 * v, l, m, lq, rq, val);
            add(2 * v + 1, m + 1, r, lq, rq, val);
        }
        update(v);
    }

    int get(int v, int l, int r, int lq, int rq) {
        if (max(l, lq) > min(r, rq))
            return MIN_VAL;
        if (lq <= l && r <= rq)
            return t[v];
        int m = (l + r) / 2;
        push(v);
        return max(get(2 * v, l, m, lq, rq), get(2 * v + 1, m + 1, r, lq, rq));
    }
};

DashaPusyaTree t;
set<int> positions[MAX_VAL + 1];
vector<int> a;
int n, m, k;

pair<int, int> getSegment(int x, int pos) {
    set<int>::iterator it = positions[x].find(pos);
    int p1 = -a.size(), p2 = 2 * a.size();
    if (it != positions[x].begin()) p1 = *(--it), ++it;
    if (++it != positions[x].end()) p2 = *it;
    --it;
    int l = max(0, pos - k + 1), r = pos;
    l = max(l, p1 + 1);
    r = min(r, p2 - k);
    return make_pair(l, r);
}

void setVal(int pos, int newX) {
    int oldX = a[pos];
    if (newX == oldX) return;
    pair<int, int> seg = getSegment(oldX, pos);
    if (seg.first <= seg.second)
        t.add(seg.first, seg.second, -1);
    positions[oldX].erase(pos);
    positions[newX].insert(pos);
    seg = getSegment(newX, pos);
    if (seg.first <= seg.second)
        t.add(seg.first, seg.second, 1);
    a[pos] = newX;
}

int main() {
    freopen("different.in", "r", stdin);
    freopen("different.out", "w", stdout);
    cin >> n >> m >> k;
    a.resize(n);
    vector<int> b(n - k + 1, 1);
    t = DashaPusyaTree(n - k + 1, b);
    for (int i = 0; i < n; ++i) positions[0].insert(i);

    for (int i = 0; i < n; ++i) {
        int x;
        scanf("%d", &x);
        setVal(i, x);
    }

    for (int i = 0; i < m; ++i) {
        int tp, x, y;
        scanf("%d%d%d", &tp, &x, &y);
        if (tp == 1)
            setVal(x - 1, y);
        else
            printf("%d\n", t.get(x - 1, y - k));
    }
    return 0;
}
