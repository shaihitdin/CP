#include <iostream>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
using namespace std;
const int MAX_VAL = 1e6;

int main() {
    freopen("different.in", "r", stdin);
    freopen("different.out", "w", stdout);
    int n, m, k;
    cin >> n >> m >> k;
    vector<int> a(n);

    for (int i = 0; i < n; ++i)
        scanf("%d", &a[i]);

    for (int i = 0; i < m; ++i) {
        int tp, x, y;
        scanf("%d%d%d", &tp, &x, &y);
        if (tp == 1)
            a[x - 1] = y;
        else {
            map<int, int> cnt;
            --x, --y;
            for (int j = x; j < x + k; ++j)
                cnt[a[j]]++;
            int ans = cnt.size();
            for (int j = x; j <= y - k; ++j) {
                cnt[a[j]]--;
                cnt[a[j + k]]++;
                if (cnt[a[j]] == 0) cnt.erase(a[j]);
                ans = max(ans, (int)cnt.size());
            }
            printf("%d\n", ans);
        }
    }
    return 0;
}
