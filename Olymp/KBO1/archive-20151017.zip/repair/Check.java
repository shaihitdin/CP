/**
 * Created by Shovkoplias on 16.10.2015.
 */
import ru.ifmo.testlib.Checker;
import ru.ifmo.testlib.InStream;
import ru.ifmo.testlib.Outcome;

public class Check implements Checker {

    final int MAX_VALUE = 100_005;

    @Override
    public Outcome test(InStream inf, InStream ouf, InStream ans) {
        int n = inf.nextInt();
        int sum = inf.nextInt();
        int mul = inf.nextInt();
        int cnt[] = new int[MAX_VALUE];

        for (int i = 0; i < n; i++) {
            int tmp = inf.nextInt();
            cnt[tmp]++;
        }

        //Jury answer
        int jX = ans.nextInt();
        int jY, jZ;
        if (jX == -1) {
            jY = -1;
            jZ = -1;
        } else {
            jY = ans.nextInt();
            jZ = ans.nextInt();
        }

        //Contestant answer
        int cX = ouf.nextInt();
        int cY, cZ;
        if (cX == -1) {
            cY = -1;
            cZ = -1;
        } else {
            cY = ouf.nextInt();
            cZ = ouf.nextInt();
        }

        //if answer doesn't exist
        if (cX == -1 && jX == -1) {
            return new Outcome(Outcome.Type.OK, String.format("-1"));
        }

        //else
        if (cX == -1) {
            return new Outcome(Outcome.Type.WA,
                    String.format("Contestant doesn't find answer \"%d %d %d\"", jX, jY, jZ));
        }

        cnt[cX]--;
        cnt[cY]--;
        cnt[cZ]--;

        if (cnt[cX] < 0) {
            return new Outcome(Outcome.Type.WA, String.format("not enought %d", cX));
        }

        if (cnt[cY] < 0) {
            return new Outcome(Outcome.Type.WA, String.format("not enought %d", cY));
        }

        if (cnt[cZ] < 0) {
            return new Outcome(Outcome.Type.WA, String.format("not enought %d", cZ));
        }

        if (cX + cY + cZ != sum) {
            return new Outcome(Outcome.Type.WA, String.format("%d+%d+%d!=%d", cX, cY, cZ, sum));
        }

        if ((long)cX * cY * cZ != mul) {
            return new Outcome(Outcome.Type.WA, String.format("%d*%d*%d!=%d", cX, cY, cZ, mul));
        }

        if (jX == -1) {
            return new Outcome(Outcome.Type.FAIL, String.format("Jury doesn't find answer \"%d %d %d\"", cX, cY, cZ));
        }

        return new Outcome(Outcome.Type.OK, String.format("%d %d %d", cX, cY, cZ));
    }


}
