#include <iostream>
#include <cstdio>
using namespace std;
const int N = 1e5 + 10;
int a[N], cnt[N];
int main() {
    freopen("repair.in", "r", stdin);
    freopen("repair.out", "w", stdout);
    int n, A, B;
    cin >> n >> A >> B;
    for (int i = 0; i < n; ++i) {
        scanf("%d", &a[i]);
        cnt[a[i]]++;
    }
    for (int i = 0; i < n; ++i) {
        if (B % a[i] == 0) {
            --cnt[a[i]];
            int d = 1, x = B / a[i];
            while (d * d <= x) {
                if (x % d == 0 && (d == x / d && cnt[d] >= 2 || d != x / d && cnt[d] && cnt[x / d])) {
                    cout << a[i] << " " << d << " " << x / d << endl;
                    return 0;
                }
                ++d;
            }
            cnt[a[i]]++;
        }
    }
    cout << -1 << endl;
    return 0;
}
