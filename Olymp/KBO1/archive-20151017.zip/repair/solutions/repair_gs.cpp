#include <cstdio>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

const int MAX_VALUE = (int)1e5 + 32;
long long sum, mul;
vector<int> cnt;

bool sqrt_in_Z(long long &n) 
{
    double q = sqrt(n);
    long long n1 = ceil(q);
    long long n2 = floor(q);
    if (n1 * n1 == n) 
    {
        n = n1;
        return true;
    }
    if (n2 * n2 == n) 
    {
        n = n2;
        return true;
    }
    return false;
}

bool find(int x, int &y, int &z) 
{
    if (mul % x != 0)
        return false;
    //z = sum - x - y;
    //y^2 - (sum - x)*y + mul/x = 0;
    int b = sum - x;
    int c = mul / x;
    long long d = (long long)b * b - 4 * c;
    if (!sqrt_in_Z(d))
        return false; 
    if ((b + d) % 2 != 0)
        return false;
    int y1 = (b + d) / 2;
    int y2 = (b - d) / 2;
    int z1 = b - y1;
    int z2 = b - y2;
    cnt[x]--;
    bool res = false;
    if ((y1 != z1 && cnt[y1] > 0 && cnt[z1] > 0) || (cnt[y1] >= 2)) 
    {
        y = y1;
        z = z1;
        res = true;
    }
    if ((y2 != z2 && cnt[y2] > 0 && cnt[z2] > 0) || (cnt[y2] >= 2)) 
    {
        y = y2;
        z = z2;
        res = true;
    }
    cnt[x]++;
    return res;
}


int main() 
{
    freopen("repair.in", "rt", stdin);
    freopen("repair.out", "wt", stdout);
    int n;
    cin >> n >> sum >> mul;
    cnt.assign(MAX_VALUE, 0);
    int tmp;
    for (int i = 0; i < n; i++)
        cin >> tmp, cnt[tmp]++;
    for (int x = 0; x <= MAX_VALUE; x++)
    {
        int y, z;
        if (cnt[x] > 0 && find(x, y, z)) 
        {
            printf("%d %d %d\n", x, y, z);
            return 0;
        }
    }
    printf("-1\n");
    return 0;    
}