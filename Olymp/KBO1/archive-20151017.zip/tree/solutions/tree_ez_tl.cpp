#include <ctime>
#include <bitset>
#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

typedef long long ll;

using namespace std;

const int MAXK = 17;
const int MAXN = 1 << MAXK;

int n, a[MAXN];
ll ans = 0;
vector<int> e[MAXN];
bool banned[MAXN];
int cnt[MAXN], h[MAXN], c[MAXN];
vector<int> vct;

void dfs(int v, int ch, int p, int cc) {
    c[v] = cc;
    h[v] = ch;
    cnt[v] = 1;
    vct.push_back(v);
    for (int i = 0; i < (int)e[v].size(); i++) {
        int to = e[v][i];
        if (banned[to] || to == p) continue;
        dfs(to, ch + 1, v, cc == -1 ? to : cc);
        cnt[v] += cnt[to];
    }
}

bool cmp(int i, int j) {
    return a[i] > a[j];
}

void solve(int v) {
    dfs(v, 0, v, -1);
    int all = cnt[v], pr = v;
    while (1) {
        bool found = 0;
        for (int i = 0; i < (int)e[v].size(); i++) {
            int to = e[v][i];
            if (to != pr && !banned[to] && cnt[to] * 2 >= all) {
                found = 1;
                pr = v;
                v = to;
                break;
            }
        }
        if (!found) break;
    }
    vct.clear();
    dfs(v, 0, v, -1);
    sort(vct.begin(), vct.end(), cmp);
    int mx1 = -1, c1 = -1, mx2 = -1, c2 = -1;
    for (int i = 0; i < (int)vct.size(); i++) {
        int u = vct[i];
        int mx = -1;
        if (c1 != c[u]) mx = mx1;
        else mx = mx2;
        if (mx != -1) ans = max(ans, 1LL * a[u] * (h[u] + mx));
        if (h[u] > mx1) {
            if (c[u] != c1) {
                c2 = c1;
                mx2 = mx1;
            }
            mx1 = h[u];
            c1 = c[u];
        }
        else if (h[u] > mx2 && c[u] != c1) {
            mx2 = h[u];
            c2 = c[u];
        }
    }
    banned[v] = 1;
    for (int i = 0; i < (int)e[v].size(); i++) {
        int to = e[v][i];
        if (!banned[to]) {
            solve(to);
        }
    }
}

int main() {
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);

    scanf("%d", &n);
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        scanf("%d%d", &u, &v);
        --u; --v;
        e[u].push_back(v);
        e[v].push_back(u);
    }
    solve(0);
    cout << ans << endl;

    return 0;
}