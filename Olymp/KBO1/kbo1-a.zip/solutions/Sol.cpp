#include <bits/stdc++.h>

using namespace std;

int main () {


	freopen ("a.in", "r", stdin);
	freopen ("a.out", "w", stdout);


	long long n;

	cin >> n;

	cout << (n * (n - 1)) / 2;

	return 0;
}