#include <bits/stdc++.h>

using namespace std;

int main () {


	freopen ("a.in", "r", stdin);
	freopen ("a.out", "w", stdout);


	long long n, ans = 0;

	cin >> n;

	for (int i = 1; i <= n; ++i)
		ans += i - 1;
	
	cout << ans;
		
	return 0;
}