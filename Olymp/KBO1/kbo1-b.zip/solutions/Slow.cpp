#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 100;

int mx;
int n, m;
bool a[N];

inline void recalc () {
	mx = n;
	for (;; --mx) {
		if (a[mx]) {
			return;
		}
	}
}


int main () {
	
	freopen ("b.in", "r", stdin);
	freopen ("b.out", "w", stdout);

	ios_base :: sync_with_stdio (0);
	cin.tie (0);

	cin >> n >> m;

	for (int i = 1; i <= n; ++i)
		cin >> a[i];

	recalc ();
		
	for (int i = 1; i <= m; ++i) {
		int x, y;
		cin >> x >> y;
		swap (a[x], a[y]);
		if (a[x] != a[y])
			recalc ();
		cout << mx << "\n";
	}
	
	return 0;
}