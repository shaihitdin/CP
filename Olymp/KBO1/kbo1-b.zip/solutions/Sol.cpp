#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 100;

set <int> Set;
int n, m;
bool a[N];

int main () {

	freopen ("b.in", "r", stdin);
	freopen ("b.out", "w", stdout);

	cin >> n >> m;

	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
		if (a[i] == 1)
			Set.insert (i);
	}

	while (m--) {
		int x, y;
		cin >> x >> y;
		if (a[x] != a[y]) {
			if (a[x] == 0) {
				Set.erase (y);
				Set.insert (x);
			} else {
				Set.erase (x);
				Set.insert (y);
			}
			swap (a[x], a[y]);
		}
		if (Set.size ()) {
			cout << *Set.rbegin () << "\n";
		} else {
			cout << 0 << "\n";
		}
	}
	

	return 0;
}